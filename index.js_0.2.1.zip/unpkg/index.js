'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

require('core-js/modules/es7.object.values');

require('core-js/modules/es7.object.entries');

require('core-js/modules/es7.object.get-own-property-descriptors');

require('core-js/modules/es7.string.pad-start');

require('core-js/modules/es7.string.pad-end');

var _jar = require('./jar');

var _jar2 = _interopRequireDefault(_jar);

var _server = require('./server');

var _server2 = _interopRequireDefault(_server);

var _save = require('./save');

var _save2 = _interopRequireDefault(_save);

var _api = require('./api');

var _api2 = _interopRequireDefault(_api);

var _path = require('path');

var path = _interopRequireWildcard(_path);

var _os = require('os');

var os = _interopRequireWildcard(_os);

var _fs = require('fs');

var fs = _interopRequireWildcard(_fs);

var _isThere = require('is-there');

var is = _interopRequireWildcard(_isThere);

var _logger = require('./lib/logger');

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _utils = require('./lib/utils');

var utils = _interopRequireWildcard(_utils);

var _mkdirp = require('mkdirp');

var _mkdirp2 = _interopRequireDefault(_mkdirp);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const defaultDB = {
  jar: [],
  server: [],
  save: [],
  version: {}
};

let MinecraftManager = class MinecraftManager {

  constructor(cfg) {
    this.downloadServer = 'http://bmclapi.bangbang93.com';
    this.saveFolder = 'save';
    this.jarFolder = 'jar';
    this.serverFolder = 'server';
    this.basePath = path.join(os.homedir(), '.minecraft-manager');
    this.dbFile = 'db.json';
    this.apiPort = 8080;
    this.rpcPort = 8081;
    this.useAPI = false;
    this.useRPC = false;
    this.api = null;
    this.setupOption = {
      updateJarVersion: false
    };
    this.auth = null;
    this.test = process.env.NODE_ENV === 'test';

    _lodash2.default.merge(this, cfg || {});

    this.dbPath = path.join(this.basePath, this.dbFile);
    this.jarPath = path.join(this.basePath, this.jarFolder);
    this.savePath = path.join(this.basePath, this.saveFolder);

    if (!is.directory(this.basePath)) {
      _mkdirp2.default.sync(this.basePath);
      _logger.logger.info(`create ${this.basePath}`);
    }

    _logger.logger.info(`use ${this.basePath}`);

    if (!is.file(this.dbPath)) {
      _logger.logger.info('cannot find db.json, create default file');
      fs.writeFileSync(this.dbPath, JSON.stringify(defaultDB));
    }

    _logger.logger.info('loading');
    this.db = JSON.parse(fs.readFileSync(this.dbPath, { encoding: 'utf-8' }));

    this.jarManager = new _jar2.default(this);
    this.saveManager = new _save2.default(this);
    this.serverManager = new _server2.default(this);

    if (this.useAPI) {
      this.api = new _api2.default(this);
    }

    process.on('SIGINT', this.shutdown.bind(this));
    process.on('SIGTERM', this.shutdown.bind(this));
    process.on('SIGHUP', this.shutdown.bind(this));
    process.on('SIGQUIT', this.shutdown.bind(this));
  }

  shutdown() {
    _logger.logger.info('shutting down');
    this.save();

    // wait some async action, i don't which it is
    setImmediate(() => {
      _logger.logger.info('Bye');
      process.exit();
    });
  }

  save() {
    this.jarManager.save();
    this.serverManager.save();
    this.saveManager.save();

    fs.writeFileSync(this.dbPath, JSON.stringify(this.db), { encoding: 'utf-8' });
    _logger.logger.info('saved');
  }

  start() {
    var _this = this;

    return (0, _asyncToGenerator3.default)(function* () {
      yield Promise.all([_this.jarManager.init(), _this.saveManager.init()]);
      yield _this.serverManager.init(); // this must be last init

      if (_this.useAPI) {
        yield utils.callAsPromise(_this.api, 'listen', _this.apiPort);
        _logger.apiLogger.info('api server listen on %d', _this.apiPort);
      }

      if (!_this.useAPI && !_this.useRPC) {
        _logger.logger.warn('please enable api or rpc');
      }

      _logger.logger.info('done!');
    })();
  }
};
exports.default = MinecraftManager;
//# sourceMappingURL=index.js.map